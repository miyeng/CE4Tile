#pragma once
class headpart
{
public:
	headpart();
	~headpart();
};

