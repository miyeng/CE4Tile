#include <iostream>
#include <fstream>
#include <string>
#include <vector>

#include <sstream>
#include <limits.h>
using namespace std;

void process(int frameNum, string prename);


void process(int frameNum,string prename) {

	string fin_string;
	vector<vector<int>> val((int)1200000, vector<int>(6, 0));


	//string filename = "C:/8iVFBv2/longdress/Ply/longdress_vox10_"; //1051~1350
	//string filename = "C:/8iVFBv2/loot/ply/loot_vox10_"; //1000~1299
	//string filename = "C:/8iVFBv2/redandblack/ply/redandblack_vox10_"; //1450~1749
	//string filename = "C:/8iVFBv2/soldier/ply/soldier_vox10_"; // 536~835
	//string filename = "C:/8iVFBv2/queen/frame_";  //0~249
	string filename = prename;
	char str[5] = "1111";

	sprintf_s(str,5,"%04d",frameNum);
	filename = filename +str + ".ply";
	cout << filename << endl;

	ifstream fin(filename);   //input file
	ofstream fout("up"+to_string(frameNum) + ".ply");    //output

	if (!fin) {
		cout << "error" << endl;
		exit(1);
	}

	//compute Y range 
	long max_Y = 0, min_Y=LONG_MAX;
	int count = 0;

	while (!fin.eof()) {

		do
		{
			getline(fin, fin_string);
		} while (fin_string != "end_header");

		for (int i = 0; i < 1200000; i++) {
			fin >> val[i][0] >> val[i][1] >> val[i][2] >> val[i][3] >> val[i][4] >> val[i][5];
			if (val[i][1] > max_Y)
				max_Y = val[i][1];
			if (val[i][1] < min_Y)
				min_Y = val[i][1];
			//count++;
			if (fin.eof()) {
				count = i;
				break;
			}
			
			
		}
	}
	cout << "Total number of points in original ply file is " << count << endl;

	fin.close();
	
	int range = round(max_Y - (max_Y - min_Y)*0.155); 
	cout << min_Y << "	" << max_Y << "	"<<range << endl;

	int num = 0;
	for (int n = 0; n < count; n++) {
		if (val[n][1]>= range)
			num++;
	}

	//----output-----

	fout << "ply" << endl;
	fout << "format ascii 1.0" << endl;
	fout << "element vertex " << num << endl;
	fout << "property float x" << endl;
	fout << "property float y" << endl;
	fout << "property float z" << endl;
	fout << "property uchar red" << endl;
	fout << "property uchar green" << endl;
	fout << "property uchar blue" << endl;
	fout << "end_header" << endl;

	for (int n = 0; n < count; n++) {
		if (val[n][1] >= range)
			fout << val[n][0] <<" "<< val[n][1]<<" " << val[n][2] <<" "<< val[n][3]<<" " << val[n][4] <<" "<< val[n][5] << endl;
	}

	fout.close();
} 


void main(int argc, char *argv[])
{
	if (argc <= 1) {
		cout << " argv[1]::prefilename" << endl;
		cout << " argv[2]::the start number of frame" << endl;
		cout << " argv[3]::the last number of frame" << endl;
		return;
	}
	

	char *prename = argv[1];

	cout << "<Start Partition>" << endl;
	
	for (int i = atoi(argv[2]); i < (atoi(argv[3])+1); i++) {
		process(i,prename);
	}
	
	return;
}