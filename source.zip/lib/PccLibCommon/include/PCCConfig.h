#define TMC2_VERSION_MAJOR 2
#define TMC2_VERSION_MINOR 0

/* Define to 1 if getrusage(2) is present */
#define HAVE_GETRUSAGE 0
