#include <iostream>
#include <fstream>
#include <string>
#include <vector>

#include <sstream>
#include <limits.h>
using namespace std;

void process(int frameNum);


/*void process(int frameNum) {

	string fin_string;
	vector<vector<int>> val((int)1200000, vector<int>(6, 0));


	//string filename ="C:/pcc_data/TMC2v2_analysis/longdress_vox10_";
	//string filename = "E:/data/8iVFBv2/8iVFBv2/longdress/Ply/longdress_vox10_";
	string filename = "D:/pcc/plyedit/combination/x64/Release/head";

	//filename = filename +".txt";
	char str[5] = "1234";
	sprintf_s(str,5, "%04d", frameNum);
	filename = filename + str + ".ply";
	cout << filename << endl;

	ifstream fin(filename,std::ios::binary);   //input file
	ofstream fout("com_"+to_string(frameNum) + ".ply");    //output
	 
	if (!fin) {
		cout << "error" << endl;
		exit(1);
	}

	
	int count = 0;

	while (!fin.eof()) {

		do
		{
			getline(fin, fin_string);
		} while (fin_string != "end_header");

		for (int i = 0; i < 1200000; i++) {
			fin >> val[i][0] >> val[i][1] >> val[i][2] >> val[i][3] >> val[i][4] >> val[i][5];
			
			if (fin.eof()) {
				count = i;
				cout << i << endl;
				break;
			}

		}
		count++;
		
	}
	
	fin.close();
	
	
	
	filename = "D:/pcc/plyedit/combination/x64/Release/body";
	sprintf_s(str, 5, "%04d", frameNum+32);
	filename = filename + str;
	ifstream fin2(filename);   //input file

	cout << filename << endl;
	if (!fin2) {
		cout << "error" << endl;
		exit(1);
	}
	while (!fin2.eof()) {

		do
		{
			getline(fin2, fin_string);
		} while (fin_string != "end_header");

	
		fin2 >> val[count][0] >> val[count][1] >> val[count][2] >> val[count][3] >> val[count][4] >> val[count][5];
		count++;
		
		
	}
	cout << count << endl;
	
	fin2.close();
	//----output-----


	fout << "ply" << endl;
	fout << "format ascii 1.0" << endl;
	fout << "element vertex " << count << endl;
	fout << "property float x" << endl;
	fout << "property float y" << endl;
	fout << "property float z" << endl;
	fout << "property uchar red" << endl;
	fout << "property uchar green" << endl;
	fout << "property uchar blue" << endl;
	fout << "end_header" << endl;

	for (int n = 0; n < count; n++) {
		
			fout << val[n][0] <<" "<< val[n][1]<<" " << val[n][2] <<" "<< val[n][3]<<" " << val[n][4] <<" "<< val[n][5] << endl;
	}

	fout.close();

}
*/


int read_ply_buffer(const std::string& filename, vector<char>& data) {

	ifstream fin(filename, ios::in);   //input file

	if (!fin) {
		std::cout << filename<<" read error" << endl;
		exit(1);
	}
	int count = 0;

	std::string fin_string;
	std::string tmp0, tmp1, tmp2;

	fin >> tmp0; // ply
	fin >> tmp0 >> tmp1 >> tmp2;
	fin >> tmp0 >> tmp1 >> count; // element, vertex, count 
	do
	{
		getline(fin, fin_string);
	} while (fin_string != "end_header");

	std::streampos p = fin.tellg();
	//std::cout << p << endl;
	fin.clear();
	fin.close();
	fin.open(filename, std::ifstream::binary);
	fin.seekg(p);

	data.resize(count * 27);
	fin.read(&data[0], count * 27);
	return count;

}

void process_buffer(string file1, string file2, int frameNum) {
	vector<char> data1,data2;
	int count1 = read_ply_buffer(file1, data1);
	int count2 = read_ply_buffer(file2, data2);

	// write
	std::cout << "write ply..." <<frameNum<< endl;
	std::cout << " number of elements: " << count1 + count2 << endl;
	ofstream fout("com_" + to_string(frameNum) + ".ply", ios::binary);    //output

	fout << "ply" << endl;
	fout << "format binary_little_endian 1.0" << endl;
	fout << "element vertex " << (count1 + count2) << endl;
	fout << "property float64 x" << endl;
	fout << "property float64 y" << endl;
	fout << "property float64 z" << endl;
	fout << "property uchar red" << endl;
	fout << "property uchar green" << endl;
	fout << "property uchar blue" << endl;
	fout << "end_header" << endl;

	fout.write(&data1[0], data1.size());
	fout.write(&data2[0], data2.size());

	fout.close();
	data1.clear();
	data2.clear();
}


int read_ply(const std::string& filename, vector< vector<double> >& val, vector< vector<unsigned char> >& color) {

	ifstream fin(filename, ios::in);   //input file

	if (!fin) {
		std::cout << "file 1 read error" << endl;
		exit(1);
	}

	int count = 0;

	std::string fin_string;
	std::string tmp0, tmp1, tmp2;

	fin >> tmp0; // ply
	fin >> tmp0 >> tmp1 >> tmp2;
	fin >> tmp0 >> tmp1 >> count; // element, vertex, count 
	do
	{
		getline(fin, fin_string);
	} while (fin_string != "end_header");

	std::streampos p = fin.tellg();
	std::cout << p << endl;
	fin.clear();
	fin.close();
	fin.open(filename, std::ifstream::binary);
	fin.seekg(p);

	for (int i = 0; i < count; i++) {
		//fin >> val[i][0] >> val[i][1] >> val[i][2] >> val[i][3] >> val[i][4] >> val[i][5];
		vector<double> pos;
		double x;
		fin.read(reinterpret_cast<char *>(&x), sizeof(char) * 8);
		pos.push_back(x);
		//val[i][0] = x;
		//std::cout << x << endl;
		double y;
		fin.read(reinterpret_cast<char *>(&y), sizeof(char) * 8);
		pos.push_back(y);
		//val[i][1] = y;
		//cout << y << endl;
		double z;
		fin.read(reinterpret_cast<char *>(&z), sizeof(char) * 8);
		pos.push_back(z);
		//val[i][2] = z;
		val.push_back(pos);

		vector<unsigned char> rgb(3);
		fin.read(reinterpret_cast<char *>(&rgb[0]), sizeof(char)*3);
		color.push_back(rgb);

		if (fin.eof()) {
			std::streampos p = fin.tellg();
			std::cout << p << endl;
			std::cout << rgb[0] << rgb[1] << rgb[2] << endl;
			break;
		}
	}
	fin.clear();
	fin.close();
	std::cout << count << endl;
	std::cout << "end of reading file 1" << endl;
	return count;
}

void process(int frameNum) {

	
	vector< vector<double> > val;	
	vector< vector<unsigned char> >color;
	
	//string filename ="C:/pcc_data/TMC2v2_analysis/longdress_vox10_";
	//string filename = "E:/data/8iVFBv2/8iVFBv2/longdress/Ply/longdress_vox10_";
	char str[5] = "1234";


	string file2 = "D:/pcc/plyedit/combination/x64/Release/body";
	sprintf_s(str, 5, "%04d", frameNum+32);
	file2 = file2 + str+".ply";
	std::cout << file2 << endl;

	int count2 = read_ply(file2, val, color);

	// read header
	string filename = "D:/pcc/plyedit/combination/x64/Release/head";
	
	sprintf_s(str, 5, "%04d", frameNum);
	filename = filename + str + ".ply";
	std::cout << filename << endl;

	int count1 = read_ply(filename, val, color);

	// write
	std::cout << "write ply..." << endl;
	std::cout << " number of elements: " << count1 + count2 << endl;
	ofstream fout("com_" + to_string(frameNum) + ".ply");    //output
	
	fout << "ply" << endl;
	fout << "format binary_little_endian 1.0" << endl;
	fout << "element vertex " << (count1+count2) << endl;
	fout << "property float64 x" << endl;
	fout << "property float64 y" << endl;
	fout << "property float64 z" << endl;
	fout << "property uchar red" << endl;
	fout << "property uchar green" << endl;
	fout << "property uchar blue" << endl;
	fout << "end_header" << endl;


	for (int n = 0; n < (count1+count2); n++) {

		//fout << val[n][0] << " " << val[n][1] << " " << val[n][2] << " " << (int)color[n][0] << " " << (int)color[n][1] << " " << (int)color[n][2] << endl;
		
		const double &pos_x = val[n][0];
		fout.write(reinterpret_cast<const char *>(&pos_x), sizeof(char) * 8);
		const double &pos_y = val[n][1];
		fout.write(reinterpret_cast<const char *>(&pos_y), sizeof(char) * 8);
		const double &pos_z = val[n][2];
		fout.write(reinterpret_cast<const char *>(&pos_z), sizeof(char) * 8);

		const unsigned char &color_r = color[n][0];
		fout.write(reinterpret_cast<const char *>(&color_r), sizeof(char));
		const unsigned char &color_g = color[n][1];
		fout.write(reinterpret_cast<const char *>(&color_g), sizeof(char));
		const unsigned char &color_b =  color[n][2];
		fout.write(reinterpret_cast<const char *>(&color_b), sizeof(char));
	}

	fout.close();

	val.clear();
	color.clear();
}

void main(int argc, char *argv[])
{
	cout << "<Start Combination two ply files>" << endl;
	if (argc <= 1) {
		cout << " argv[1]::pre_filename1" << endl;
		cout << " argv[2]::pre_filename2" << endl;
		cout << " argv[3]::the start number of frame" << endl;
		cout << " argv[4]::number of final ply files" << endl;
		return;
	}
	char *prename1 = argv[1];
	char *prename2 = argv[2];
	int start_num = atoi(argv[3]);
	int num = atoi(argv[4]);
	int framenum = start_num;

	string file1, file2;
	char str[5];
	
	int GOF_SIZE = 32;
	int output_num = start_num;
	
	for(int i=0;i<num;i++){

		sprintf_s(str, 5, "%04d", framenum);
		file1 = prename1 + string(str) + ".ply";
		int shift = 0;
		if (i < (num - (num%GOF_SIZE)))
			shift = GOF_SIZE;
		else
			shift = num % GOF_SIZE;

		sprintf_s(str, 5, "%04d", framenum + shift);
		file2 = prename2 + string(str) + ".ply";

		process_buffer(file1,file2,output_num);
		cout << output_num << endl;
		framenum++;
		output_num++;

		if ((framenum % GOF_SIZE) == 0) {
			framenum = framenum + GOF_SIZE;
			
		}


	}
	return;
}